<?php
declare(strict_types=1);

if (session_status() !== PHP_SESSION_ACTIVE) session_start();

require_once dirname(__DIR__) . '/config/Database.php';
require_once dirname(__DIR__) . '/classes/Auth.php';
require_once __DIR__ . '/SecurityService.php';

$configFile = __DIR__ . '/config.local.php';
if (!is_file($configFile)) {
    http_response_code(500);
    exit('Falta security/config.local.php');
}
$securityConfig = require $configFile;

$database = new Database();
$db = $database->getConnection();
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$auth = new Auth($db);
$auth->requireLogin();

function ahSecurityColumns(PDO $db, string $table): array {
    try {
        $rows = $db->query("SHOW COLUMNS FROM `$table`")->fetchAll(PDO::FETCH_ASSOC);
        $out = [];
        foreach ($rows as $row) $out[(string)$row['Field']] = true;
        return $out;
    } catch (Throwable $e) { return []; }
}

function ahSecuritySessionId(): int {
    $values = [
        $_SESSION['user_id'] ?? null,
        $_SESSION['usuario_id'] ?? null,
        $_SESSION['id_usuario'] ?? null,
        $_SESSION['id'] ?? null,
        is_array($_SESSION['user'] ?? null) ? ($_SESSION['user']['id'] ?? null) : null,
    ];
    foreach ($values as $value) {
        if (is_numeric($value) && (int)$value > 0) return (int)$value;
    }
    return 0;
}

function ahSecurityUser(PDO $db): array {
    $sessionRole = '';
    foreach (['rol','role','perfil','tipo_usuario'] as $key) {
        if (!empty($_SESSION[$key])) { $sessionRole = trim((string)$_SESSION[$key]); break; }
    }
    $sessionName = '';
    foreach (['nombre','name','usuario','email'] as $key) {
        if (!empty($_SESSION[$key])) { $sessionName = trim((string)$_SESSION[$key]); break; }
    }

    $id = ahSecuritySessionId();
    foreach (['ah_users','users'] as $table) {
        $columns = ahSecurityColumns($db, $table);
        if (!$columns || !$id || !isset($columns['id'])) continue;

        $roleColumn = isset($columns['rol']) ? 'rol' : (isset($columns['role']) ? 'role' : '');
        $nameColumn = isset($columns['nombre']) ? 'nombre' : (isset($columns['name']) ? 'name' : '');
        $emailColumn = isset($columns['email']) ? 'email' : (isset($columns['correo']) ? 'correo' : '');

        $select = ['id'];
        if ($roleColumn) $select[] = "`$roleColumn` AS role_value";
        if ($nameColumn) $select[] = "`$nameColumn` AS name_value";
        if ($emailColumn) $select[] = "`$emailColumn` AS email_value";

        try {
            $st = $db->prepare("SELECT " . implode(',', $select) . " FROM `$table` WHERE id=? LIMIT 1");
            $st->execute([$id]);
            if ($row = $st->fetch(PDO::FETCH_ASSOC)) {
                return [
                    'id'=>$id,
                    'role'=>trim((string)($row['role_value'] ?? $sessionRole)),
                    'name'=>trim((string)($row['name_value'] ?? $sessionName)),
                    'email'=>trim((string)($row['email_value'] ?? '')),
                    'table'=>$table,
                ];
            }
        } catch (Throwable $e) {}
    }

    return ['id'=>$id,'role'=>$sessionRole,'name'=>$sessionName ?: 'Usuario autenticado','email'=>'','table'=>''];
}

function ahSecurityIsAdmin(array $user): bool {
    $role = mb_strtolower(trim((string)($user['role'] ?? '')), 'UTF-8');
    $role = str_replace([' ','-','_'], '', $role);
    if (in_array($role, ['admin','administrador','administrator','superadmin','superusuario','root'], true)) return true;

    $permissions = $_SESSION['permisos'] ?? [];
    if (is_string($permissions)) {
        $decoded = json_decode($permissions, true);
        $permissions = is_array($decoded) ? $decoded : preg_split('/[,;|]/', $permissions);
    }
    foreach ((array)$permissions as $permission) {
        $permission = mb_strtolower(trim((string)$permission), 'UTF-8');
        if (in_array($permission, ['seguridad','administrar_seguridad','security_admin'], true)) return true;
    }
    return false;
}

$securityUser = ahSecurityUser($db);
if (!ahSecurityIsAdmin($securityUser)) {
    http_response_code(403);
    exit('Acceso restringido únicamente a administradores.');
}

$securityUserLabel = trim(
    (($securityUser['name'] ?? '') ?: 'Administrador') .
    (!empty($securityUser['email']) ? ' <' . $securityUser['email'] . '>' : '')
);

$security = new SecurityService($db, $securityConfig);

function ahSecurityCsrfToken(): string {
    if (empty($_SESSION['ah_security_csrf'])) $_SESSION['ah_security_csrf'] = bin2hex(random_bytes(32));
    return (string)$_SESSION['ah_security_csrf'];
}

function ahSecurityVerifyCsrf(): void {
    $received = (string)($_POST['csrf'] ?? '');
    if ($received === '' || !hash_equals(ahSecurityCsrfToken(), $received)) {
        throw new RuntimeException('La sesión de seguridad venció. Recargue la página.');
    }
}
