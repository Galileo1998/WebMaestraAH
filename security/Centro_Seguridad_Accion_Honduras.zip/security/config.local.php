<?php
declare(strict_types=1);

return [
    'root_path' => realpath(dirname(__DIR__)) ?: dirname(__DIR__),
    'storage_path' => dirname(dirname(__DIR__)) . '/accion_security_storage',
    'cron_token' => '00c56aacd539414260d250b68f1dcfce45f68d2a7d43842f3c1f308e61419042',
    'scan' => [
        'max_content_bytes' => 8 * 1024 * 1024,
        'web_file_limit' => 12000,
        'clamav_enabled' => true,
        'clamav_binary' => 'clamscan',
        'exclude_paths' => ['.git','node_modules','vendor','uploads/formularios','cache','tmp','logs'],
        'upload_like_paths' => ['uploads','images','img','media','archivos','documentos'],
    ],
    'backup' => [
        'extensions' => ['php','phtml','php3','php4','php5','php7','php8','inc','js','css','html','htm','json','xml','sql','md','txt','yml','yaml','ini','conf'],
        'special_files' => ['.htaccess','.gitignore','composer.json','composer.lock','package.json','package-lock.json'],
        'exclude_paths' => ['.git','node_modules','vendor','uploads','cache','tmp','logs'],
        'keep_last' => 12,
    ],
    'git' => [
        'enabled' => true,
        'binary' => 'git',
        'remote' => 'origin',
        'block_push_on_high_findings' => true,
        'user_name' => 'Acción Honduras Security',
        'user_email' => 'sistemas@accionhonduras.org',
    ],
    'notifications' => ['emails' => [], 'from' => 'seguridad@accionhonduras.org'],
];
