<?php
// config/db.php

$host = "localhost";
$usuario = "root";  // Usuario por defecto de XAMPP
$password = "1998";     // Contraseña (déjala vacía si no configuraste una)
$base_datos = "participacion_af26";

$mysqli = new mysqli($host, $usuario, $password, $base_datos);

if ($mysqli->connect_error) {
    die("Error de conexión: " . $mysqli->connect_error);
}

// Para que las tildes y ñ se guarden bien
$mysqli->set_charset("utf8mb4");
?>